<?php  
/**
*
* Trigger this file on plugin Uninstall
*
* @package YuukiPlugin
*/ 

if ( ! defined('WP_UNINSTALL_PLUGIN') ) {
	die;
}

// Clear Database