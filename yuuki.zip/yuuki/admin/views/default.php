<div class="wrap">
    <h2> Bcodes Slider
        <a class="add-new-h2 data-toggle-add"> Add New </a>
    	<!-- <a class="add-new-h2"> Add New </a> -->
	</h2>
    
    <div class="tes-toggle" style="display: none; margin-top: 20px;">
        <form class="new_slide" method="post">
            <div class="row">
                <input  class="new_slider_name" type="text" name="slider_name">
                <button class="new_slider_btn add-new-h2" style="top: 0;"> add </button>
            </div>
        </form>
    </div>

    <form class="default" method="post">
        <input type="hidden" name="page" value="ttest_list_table">

        <?php
        $list_table = new Slider_List_Table();
        $list_table->prepare_items();
        $list_table->search_box( 'search', 'search_id' );
        $list_table->display();
        ?>
    </form>
</div>

<!-- <a href=" //admin_url( 'admin.php?page=bcodes-slider&action=add_new' );" class="add-new-h2"> Add New </a> -->
