<form class="yuuki-form" method="post" >

	<label for="header_scripts"> 
		<h1> Slider </h1> 
	</label>

	<div class="slider_wrapper">

		<?php $index = 0;
			$index++;
			echo "
			<div class='image_wrap'>
				<div class='add_image direct_media' data-preview='slide-$index'>
					<img id='slide-$index' class='preview' width='200' height='150'>
					<input id='slide-$index' type='text' class='url' name='url-pic[]' style='display: none;'>
				</div>
			</div>
			";
		?>
		<input id="batas" value="<?php echo get_last_id()[0]->id ?>" name="slider_id" style="display: none;">
	</div>

		<input type="submit" name="submit_scripts_update" class="yuuki-submit" value="Save">
		<button type="button" class="add"> + </button>
</form>
