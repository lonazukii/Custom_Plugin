<?php

/**
 * Get all bcodes-slider
 *
 * @param $args array
 *
 * @return array
 */
function test_get_all_bcodes_slider( $args = array() ) {
    global $wpdb;

    $defaults = array(
        'number'     => 20,
        'offset'     => 0,
        'orderby'    => 'id',
        'order'      => 'ASC',
    );

    $args      = wp_parse_args( $args, $defaults );
    $cache_key = 'bcodes-slider-all';
    $items     = wp_cache_get( $cache_key, 'wedevs' );

    if ( false === $items ) {
        $items = $wpdb->get_results( 'SELECT * FROM ' . $wpdb->prefix . 'yuuki_slider ORDER BY ' . $args['orderby'] .' ' . $args['order'] .' LIMIT ' . $args['offset'] . ', ' . $args['number'] );

        wp_cache_set( $cache_key, $items, 'wedevs' );
    }

    return $items;
}

/**
 * Fetch all bcodes-slider from database
 *
 * @return array
 */
function test_get_bcodes_slider_count() {
    global $wpdb;

    return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $wpdb->prefix . 'yuuki_slider' );
}

/**
 * Fetch a single bcodes-slider from database
 *
 * @param int   $id
 *
 * @return array
 */
function test_get_bcodes_slider( $id = 0 ) {
    global $wpdb;

    return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . $wpdb->prefix . 'yuuki_slider WHERE id = %d', $id ) );
}