<?php


function tes ($attr){
	global $wpdb;

	// $id = $attr['id'];
	$name = $attr['name'];
	$tb1  = $wpdb->prefix. "yuuki_plugin";
	$tb2  = $wpdb->prefix. "yuuki_slider";
	$sql  = $wpdb->get_results("SELECT * FROM $tb2 INNER JOIN $tb1 WHERE $tb2.slider_name = '$name' AND $tb2.id = $tb1.slider_id");
	// $tes = "";

	// Get Atrribute Width
	if (!isset($attr['width'])) {	
		$width = 300; 
	}else{ 
		$width = $attr['width']; 
	}
	if (!isset($attr['height'])){
		$height = 100;
	}else{
		$height = $attr['height']; 
	}

	echo "<div class='wrap' style='margin: 20px'>";
	foreach ($sql as $key => $value) {
		 echo "<img class='plugin' src='$value->url' style='margin:10px auto; width:".$width."; height:".$height.";'>";
	}
	echo "
	</div>
	<div class='arrow'>
		<button class='prev' onclick='plusDivs(-1)'>&#10094;</button>
		<button class='next' onclick='plusDivs(1)'>&#10095;</button>
	</div>";
	// return $tes;
}add_shortcode( 'yuuki', 'tes');


