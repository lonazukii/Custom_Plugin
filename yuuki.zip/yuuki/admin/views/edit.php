<form class="yuuki-form-edit" method="post" >

	<label for="header_scripts"> 
		<?php 
			if (get_data_slider_null() == null) {
				echo "<h1> Slider </h1>"; 
			}else{
				echo "<h1>".get_data_slider_null()[0]->slider_name."</h1>"; 
				echo "<p>".get_data_slider_null()[0]->shortcode."</p>"; 
			}
		?>
	</label>
		<button class="toggle-slider" type='button'> SLider Image Toggle </button>
	<div class="slider_wrapper">

		<?php $index = 0;
			if ( count(get_data_slider_null()) > 0) {
				foreach (get_data_slider_null() as $key => $value) {
					$index++;
					echo "
					<div class='image_wrap'>
						<div class='add_image direct_media' data-preview='slide-$index'>
							<img id='slide-$index' src='$value->url' width='200' height='150'>
							<input id='slide-$index' type='text' value='$value->url' class='url' name='url-pic[]'>
							<input id='slide-$index' type='text' name='id-pic[]' value='$value->id'>
						</div>
							<button type='button' data-id='$value->id' class='delete'> Delete </button>
					</div>	
					";
				}
			}else{
				$index++;
				echo "
					<div class='image_wrap'>
 						<div class='add_image direct_media' data-preview='slide-$index'>
 							<img id='slide-$index' class='preview' width='200px' height='150px'>
 							<input id='slide-$index' data-insert='1' type='text' class='url' name='url-pic[]' value=''>
 						</div>
 						<button type='button' data-id='0' class='delete' style='display:none;'> Delete </button>
 					</div>
				";
			}
		?>
		<input id="batas" value="<?php echo $_GET['id'] ?>" name="slider_id" style="display: none;">
	</div>

		<button type="button" class="add"> + </button>
		<input type="submit" name="submit_scripts_update" class="yuuki-submit" value="Save">
</form>

<div class="wrapper-custom" >
	<div class="select-type">
		<div class="row">
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel, reprehenderit cupiditate inventore incidunt nostrum eum illum aliquam minima ad quos.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel, reprehenderit cupiditate inventore incidunt nostrum eum illum aliquam minima ad quos.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel, reprehenderit cupiditate inventore incidunt nostrum eum illum aliquam minima ad quos.</p>
		</div>
	</div>
</div>