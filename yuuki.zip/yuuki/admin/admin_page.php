<?php 
	$dummy_slide = plugins_url('assets/images/dummy-slide.png', __FILE__); 
	$action = isset( $_GET['action'] ) ? $_GET['action'] : 'list';
    $id     = isset( $_GET['id'] ) ? $_GET['id'] : 0;
    
		switch ($action) {
			case "add":
	            $template = dirname( __FILE__ ) . '/views/add.php';
	        break;	        
	        case "edit":
	            $template = dirname( __FILE__ ) . '/views/edit.php';
	        break;	        
	        default:
	    		$template = dirname( __FILE__ ) . '/views/default.php';
	    	break;
		}
    
		if ( file_exists( $template ) ) {
            include $template;
        }


