<?php 
/*
   Plugin Name: Bcodes Slider
   Plugin URI: #
   description: dik sakedik sakedik sakemadefakedik sakedik saaaakeediiik
   Version: 1.0
   Author: Y.U.U.K.I
   Author URI: #
   Text Domain : yuuki-plugin
*/	
	
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

add_action( 'init', function(){
	include dirname(__FILE__). '/includes/install.php';
	include dirname(__FILE__). '/admin/views/slider_list_table.php';
	include dirname(__FILE__). '/admin/views/slider_functions.php';
   include dirname(__FILE__). '/admin/views/all-shortcode.php';

   new YuukiPlugin();
});


