<?php 
/**
* After Activation button clicked HA HA :v
*/ 

if ( ! class_exists ( 'WP_List_Table' ) ) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class YuukiPlugin extends WP_List_Table{	

	function __construct(){
		// Doing Install DB
		add_action( 'init', array( $this, 'install_DB'));
		// Doing Adding Menu to admin Page
		add_action( 'admin_menu', array( $this, 'admin_menu'));

		// Load Css or JS
			// for admin page
			add_action('admin_enqueue_scripts', array($this, 'enque'));
			// for content page
			add_action('wp_enqueue_scripts', array($this, 'enque'));
	}

	// for Install DB Image
	function install_DB(){
		global $wpdb;
		$wp_yuuki_plugin = $wpdb->prefix . 'yuuki_plugin';
		require_once(ABSPATH .  'wp-admin/includes/upgrade.php');

		if ($wpdb->get_var('SHOW TABLES LIKE "wp_yuuki_plugin"') == 0) {
			$sql = "
			CREATE TABLE `wp_yuuki_plugin` (
				 `id` int(11) NOT NULL AUTO_INCREMENT,
				 `url` varchar(300) NOT NULL,
				 `slider_id` int(11) NOT NULL,
				 `create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				 PRIMARY KEY (`id`)
				) 
			CREATE TABLE `wp_yuuki_slider` (
				 `id` int(11) NOT NULL AUTO_INCREMENT,
				 `shortcode` varchar(150) NOT NULL,
				 `slider_name` varchar(150) NOT NULL,
				 PRIMARY KEY (`id`)
				) 
			ENGINE=InnoDB DEFAULT CHARSET=latin1";
			dbDelta($sql);
		}
	}
	
	//  Add File like CSS or JS
	function enque(){
    	wp_enqueue_media();
		wp_enqueue_style('Bcs-Style', plugins_url('../assets/css/style.css', __FILE__));
		wp_enqueue_script('Bcs-Js', plugins_url('../assets/js/main.js', __FILE__), array('jquery') , '1.0.0', true);
	}

	function admin_menu(){
		add_menu_page('Bcodes Slider' /*title*/, 'Bcodes Slider' /*Label option*/, 'manage_options',
			'bcodes-slider' /*slug*/, 'plugin_page' /*call back*/, ''/*icon*/, null );
	}

}	




function plugin_page(){
	wp_enqueue_media();
	if (array_key_exists('submit_scripts_update',$_POST)) {
		// update_option('yuuki_header_scripts',$_POST['header_scripts']);
		// update_option('yuuki_footer_scripts',$_POST['footer_scripts']);

		?>
			<div id="alert-updated" class="updated updated-eror">
				<strong> Content has Updated .. :) </strong>
			</div>
		<?php
	}
	// $header_scripts = get_option('yuuki_header_scripts','none');
	// $footer_scripts = get_option('yuuki_footer_scripts','none');
	include dirname(__FILE__) . '/../admin/admin_page.php';
}

// Insert Slider
function insert_slider(){
	global $wpdb;
	$s_name = trim($_POST['slider_name']);
	$scd = "[yukii name='$s_name']";
	$tb = $wpdb->prefix. "yuuki_slider";
	$wpdb->insert(
		$tb, array(
			"shortcode"   => $scd,
			"slider_name" => $s_name,
		)
	);
	die();
}add_action('wp_ajax_slider', 'insert_slider');


// Edit Slider
function edit_slider(){
	global $wpdb;
	$s_name = trim($_POST['slider_name']);
	$scd = "[yukii name='$s_name']";
	$tb = $wpdb->prefix. "yuuki_slider";
	$wpdb->query("UPDATE $tb SET `shortcode`= $scd, `slider_name`= $s_name, WHERE id = $id");
	$wpdb->insert(
		$tb, array(
			"shortcode"   => $scd,
			"slider_name" => $s_name,
		)
	);
	die();
}add_action('wp_ajax_slider', 'insert_slider');

// function tes_99($attr){
// 	$txt = "<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia mollitia dicta quaerat eligendi vel consectetur nulla suscipit, quas deleniti sequi harum facere quae magnam odio. Magni eius non voluptatum, facilis ducimus pariatur iusto consectetur possimus nisi. Nulla tempore quis ea nam id saepe voluptate libero eveniet dignissimos doloremque! Minima, enim.</p>";
// 	shortcode_atts(
// 		array(
// 			'repeat' => 1,
// 		),$attr
// 	);
// 	return str_repeat($txt, $attr['repeat']);
// }add_shortcode( "yuuki", 'tes_99');

// Delete SLider
function delete_slider(){
	global $wpdb;
	$id   = $_POST['id'];
	$tb   = $wpdb->prefix."yuuki_slider";
	$sql  = $wpdb->query("DELETE FROM $tb WHERE id = $id");
	return $sql;
}add_action('wp_ajax_delete', 'delete_slider');

// Call Slider data
function call_data_slider(){
	global $wpdb;
	$tb  = $wpdb->prefix. "yuuki_slider";
	$sql = $wpdb->get_results( " SELECT * FROM $tb ");
	return $sql;
}add_action('wp_ajax_call_slider', 'call_data_slider');

// Insert Image
function insert_image(){
	global $wpdb;
	$link = $_POST['url_pict'];
	$id = $_POST['id'];
	$tb = $wpdb->prefix. "yuuki_plugin";
	for ($i=0; $i < count($link) ; $i++) { 
		$wpdb->insert(
			$tb, array(
				"url"       => $link[$i],
				"slider_id" => $id,
			)
		);		
	}
	die();
}add_action('wp_ajax_try', 'insert_image');

// Tes Update Image
function update_image(){
	global $wpdb;
	$link = $_POST['url_pict'];
	$id = $_POST['id'];
	$image_id = $_POST['image_id'];
	$tb = $wpdb->prefix. "yuuki_plugin";
	for ($i=0; $i < count($link) ; $i++) { 
		$wpdb->update(
			$tb,array(
				"url" => $link[$i],
			),
			array( 'id' => $image_id[$i] )
		);
	}
	// var_dump($image_id);
	die();
}add_action('wp_ajax_try_update', 'update_image');
// END




// Delete Image
function delete_image(){
	global $wpdb;
	$id   = $_POST['id'];
	$tb   = $wpdb->prefix."yuuki_plugin";
	$sql  = $wpdb->query("DELETE FROM $tb WHERE id = $id");
	return $sql;
	// $wpdb->query( $wpdb->prepare("DELETE FROM $tb WHERE id = $id") );
}add_action('wp_ajax_delete', 'delete_image');



// Get Data slider
function get_data_slider_null(){
	global $wpdb;
	$id = $_GET['id'];
	$tb1  = $wpdb->prefix. "yuuki_plugin";
	$tb2  = $wpdb->prefix. "yuuki_slider";
	$sql = $wpdb->get_results("SELECT * FROM $tb1 INNER JOIN $tb2 ON slider_id = $tb2.id WHERE slider_id = $id");
	return $sql;
}add_action(__FILE__, 'get_data_slider_null');

function get_last_id(){
	global $wpdb;
	$tb  = $wpdb->prefix. "yuuki_slider";
	$sql = $wpdb->get_results("SELECT * FROM $tb ORDER BY `id` DESC LIMIT 1");
	return $sql;
}add_action(__FILE__, 'get_last_id');

// // TES
// function load_admin_libs() {
//     wp_enqueue_media();
//     wp_enqueue_script( 'wp-media-uploader', __FILE__ . 'wp_media_uploader.js', array( 'jquery' ), 1.0 );
// }
// add_action( 'admin_enqueue_scripts', 'load_admin_libs' );


// function yuuki_header(){
// 	$header_scripts = get_option('yuuki_header_scripts','none');
// 	print $header_scripts;
// // }add_action('wp_head', 'yuuki_header');
// function yuuki_footer(){
// }add_action('wp_footer', 'yuuki_footer');