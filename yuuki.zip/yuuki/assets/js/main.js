jQuery(document).ready(function(){
	var $ = jQuery;
	var meidauploader;
	var index = 1;
	var context;
	// Direct to media WP
	$(document).on('click', '.direct_media', open_media_window);
	
	function open_media_window(e) {
		context = $(this).data('preview');
		if (meidauploader) {
			meidauploader.open();
			return ;
		}
		meidauploader = wp.media.frames.file_name = wp.media({
			title : "Select Pict",
			button:{ text: "Choose Pict", },
			multiple: false
		});
		meidauploader.on('select', function(){
			attachment = meidauploader.state().get('selection').first().toJSON();
			$('#' + context).attr('src', attachment.url);
			$('#' + context).parent().find('.url').val(attachment.url);

			//  Insert image
   			
   			var slide_id = jQuery('input[name="slider_id"]').val();
			var url_pict = $('input.url').map(function(index, el){ var link = el.getAttribute('data-insert');if (link == 1) { return el.value;  }}).get();
   			var data_id  = $('button.delete').map(function(index, el){ var id = el.getAttribute('data-id');	if (id == 0) { return el; }}).get();
   			var image_id = jQuery('input[name="id-pic[]"]').map(function(index, el){ return el.value; }).get();
   			
   			if (data_id.length > 0) {
		   		jQuery.ajax({
					url:"admin-ajax.php",
					data:{action : "try", url_pict:url_pict, id:slide_id},
					method: "POST",
					success: function(respon){ location.reload(true)}
				});
   			}else{

   			var url_pict = jQuery('input[name="url-pic[]"]').map(function(index, el){ return el.value; }).get();

		   		jQuery.ajax({
					url:"admin-ajax.php",
					data:{action : "try_update", image_id:image_id,url_pict:url_pict, id:slide_id},
					method: "POST",
					success: function(respon){ location.reload(true)}
				});
   			}
		});
	}

// Function to add new Image
 jQuery('.add').on('click', function(){
 	index++;
 	var data_id = $(".add_image");

 	var dummy_image  = "<div class='image_wrap'>";
 		dummy_image += "<div class='add_image direct_media' data-preview='slide-"+(data_id.length+1)+"'>";
		dummy_image	+= "<img id='slide-"+(data_id.length+1)+"' class='preview' width='200px' height='150px'>";
		dummy_image += "<input id='slide-"+(data_id.length+1)+"' data-insert='1' type='text' class='url' name='url-pic[]' value=''>";
		dummy_image += "</div>";
		dummy_image += "<button type='button' data-id='0' class='delete'> Delete </button>";
		dummy_image += "</div>";
 	jQuery("#batas").before(dummy_image);
 	return false;
 });
 		
// END

// Function to Submit data Connect to Database
   	jQuery(document).on('submit', '.new_slide', function(e){
   		e.preventDefault();

   		// Input Slider to Database
   		var slide_name = jQuery('input[name="slider_name"]').val();
   		jQuery.ajax({
			url:"admin-ajax.php",
			data:{action : "slider", slider_name:slide_name},
			method: "POST",
			success: function(respon){ location.reload(true); }
		});
   	});

   	$('.submitdelete').click(function(e){
   		e.preventDefault();
   			context = $(this).data('id');
   		jQuery.ajax({
   			url:"admin-ajax.php",
   			data:{action : "delete", id:context},
   			method: "POST",
   			success : function(respon){location.reload(true);}
   		});
   	});

   	$(document).on('click', '.delete', function(e){
   		e.preventDefault();
   			centex = $(this).data('id');
  			mv = $(this).parent();
  			mv.remove();

   			jQuery.ajax({
	   			url:"admin-ajax.php",
	   			data:{action : "delete", id:centex},
	   			method: "POST",
	   			success : function(respon){location.reload(true)}
	   		});
   	});

// Toggle to insert new slider
	$('.data-toggle-add').click(function(){
		$(".tes-toggle").toggle(300);
	})

	$('.toggle-slider').click(function(){
		$(".slider_wrapper").toggle(300);
	})

});

// Slide function
   	var slideIndex = 1;
	showDivs(slideIndex);

	function plusDivs(n) {
	  showDivs(slideIndex += n);
	}

	function showDivs(n) {
	  var i;
	  var x = document.getElementsByClassName("plugin");
	  if (n > x.length) {slideIndex = 1}    
	  if (n < 1) {slideIndex = x.length}
	  for (i = 0; i < x.length; i++) {
	     x[i].style.display = "none";  
	  }
	  x[slideIndex-1].style.display = "block";  
	}
// END
